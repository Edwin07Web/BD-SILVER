﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using MySql.Data.MySqlClient;

namespace Silver
{
    public partial class RTarjeton : Form
    {
        public RTarjeton()
        {
            InitializeComponent();
        }

        //Para arrastrar la interfaz

        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lparam);


        private void registro_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
           
        }

        //Boton GUARDAR REGISTRO
        private void button1_Click(object sender, EventArgs e)
        {

            BaseDatos.registroTarjeton(BaseDatos.ConectarBd(),textBox1.Text, textBox2.Text, textBox3.Text, textBox4.Text,textBox5.Text,comboBox1.Text, textBox6.Text);
            
           
        }


    
        //Boton de Limpiar
        private void button2_Click(object sender, EventArgs e)
        {
           
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
          
      
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void Nombre_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        //Ir al boton de Menu
        private void gunaAdvenceButton3_Click(object sender, EventArgs e)
        {
            Menu men= new Menu();
            this.Hide();
            men.Show();

        }

        //Ir al Boton Buscar de Tarjeton
        private void gunaAdvenceButton1_Click(object sender, EventArgs e)
        {
            BuscarTarjeton bus = new BuscarTarjeton();
            this.Hide();
            bus.Show();
        }

        //Ir a Eliminar de Tarjeton
        private void gunaAdvenceButton2_Click(object sender, EventArgs e)
        {
            EliminarTarjeton eli = new EliminarTarjeton();
            this.Hide();
            eli.Show();
        }


        // CRUD
        private void button3_Click(object sender, EventArgs e)
        {

          
                MySqlCommand cmd = new MySqlCommand("SELECT * FROM bdtarjeton",BaseDatos.ConectarBd());
                MySqlDataAdapter ver = new MySqlDataAdapter();
                ver.SelectCommand = cmd;
            DataTable tabla = new DataTable();
                ver.Fill(tabla);
            dataGridView1.DataSource = tabla;

            
        }

        //Booton de cerrar ("X")
        private void label11_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        //cerrar sesion
        private void pictureBox3_Click(object sender, EventArgs e)
        {
            Form1 login = new Form1();
            this.Hide();
            login.Show();
        }

        //Mover app
        private void registro_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void panel2_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void bunifuSeparator3_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void gunaAdvenceButton4_Click(object sender, EventArgs e)
        {
            Dashboard das = new Dashboard();
            das.Show();
        }

        //Llave de cierre
    }
}
