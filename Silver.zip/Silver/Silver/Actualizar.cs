﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using MySql.Data.MySqlClient;

namespace Silver
{
    public partial class Actualizar : Form
    {
        public Actualizar()
        {
            InitializeComponent();
        }


        //Para arrastrar la interfaz

        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lparam);

        //Boton actualizar
        private void button1_Click(object sender, EventArgs e)
        {
            BaseDatos.Actualizar(BaseDatos.ConectarBd(), textBox1.Text, textBox2.Text, textBox3.Text, textBox4.Text, textBox5.Text, textBox6.Text, textBox7.Text, comboBox1.Text);
        }


        //Ir al boton Registro
        private void gunaAdvenceButton3_Click(object sender, EventArgs e)
        {
            registro regis = new registro();
            this.Hide();
            regis.Show();
        }

        //CRUD
        private void button3_Click(object sender, EventArgs e)
        {
            MySqlCommand cmd = new MySqlCommand("SELECT * FROM bdnube", BaseDatos.ConectarBd());
            MySqlDataAdapter ver = new MySqlDataAdapter();
            ver.SelectCommand = cmd;
            DataTable tabla = new DataTable();
            ver.Fill(tabla);
            dataGridView1.DataSource = tabla;

        }

        private void gunaAdvenceButton1_Click(object sender, EventArgs e)
        {
            Buscar bus = new Buscar();
            this.Hide();
            bus.Show();
        }

        private void gunaAdvenceButton2_Click(object sender, EventArgs e)
        {
            Eliminar eli = new Eliminar();
            this.Hide();
            eli.Show();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            Form1 login = new Form1();
            this.Hide();
            login.Show();
        }

        private void panel2_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void Actualizar_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void label11_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void bunifuSeparator3_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
    }
}
