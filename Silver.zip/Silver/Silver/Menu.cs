﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using MySql.Data.MySqlClient;

namespace Silver
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }

        //Para arrastrar la interfaz

        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lparam);

        private void label11_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void bunifuSeparator3_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {


            Form1 login = new Form1();
            this.Hide();
            login.Show();
        }

        //Boton de Entrada
        private void gunaAdvenceButton3_Click(object sender, EventArgs e)
        {
            REntrada entrada = new REntrada();
            this.Hide();
            entrada.Show();
        }

        //Boton de Salida
        private void gunaAdvenceButton1_Click(object sender, EventArgs e)
        {
            RSalida salida = new RSalida();
            this.Hide();
            salida.Show();
        }


        //Boton de Registro No. Tarjeton 
        private void gunaAdvenceButton2_Click(object sender, EventArgs e)
        {
            RTarjeton tarjeton = new RTarjeton();
            this.Hide();
            tarjeton.Show();
        }

        private void pictureBox2_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void panel2_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }


        //Fecha y hora
        private void timer1_Tick(object sender, EventArgs e)
        {
            labelhora.Text = DateTime.Now.ToString("HH:mm:ss");
            labelfecha.Text = DateTime.Now.ToLongDateString();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
    }
}
