﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Silver
{
    class BaseDatos
    {
        // 1-Conexión a la Base de datos ADMINISTRADOR
        public static MySqlConnection ConectarBd()
        {
            
            MySqlConnection conectar;
            
            string stringConection = "server=bu2dhmwtysjpqzgxggtc-mysql.services.clever-cloud.com;port=3306;database=bu2dhmwtysjpqzgxggtc;user=uzqtm0ogszmhzb2m;password=AYZhDxXQgM2bzEWhb54F;";
            conectar = new MySqlConnection(stringConection);
            conectar.Open();
            return conectar;
        }

        //Formulario Inicio de Sesion

        // 2- Metodo de Inicio de Sesion Administrador

        public static string ValUsuario(MySqlConnection conectar, string Id, string Contraseña)
        {

            string id = null, contraseña = null, inicio = null; ;
            string cadenaValUsuario = "select * from bdnube where id ='" + id + "' and contraseña = '" + contraseña + "'";
            MySqlCommand cmd = new MySqlCommand(cadenaValUsuario, conectar);


            return inicio;


        }



        //3--Metodo de Nivel = si el ID es correcto y el Nivel igual entra , dependiendo Si es "Admin" o "Usuario"
        public static string ConsultaNivel(MySqlConnection conectar, string id, string contraseña)
        {
            string resnivel = null;
            string cadenaValUsuario = "select * from bdnube where id ='" + id + "' and contraseña = '" + contraseña + "'";
            MySqlCommand cmd = new MySqlCommand(cadenaValUsuario, conectar);

            MySqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                resnivel = reader.GetString(7);
            }
            return resnivel;
        }

        //-Metodo de acceso = si el ID no existe no entra 

        public static string ConsultaAcceso(MySqlConnection conectar, string id, string contraseña)
        {
            string regresa = null;
            string cadenaValUsuario = "select * from bdnube where id ='" + id + "' and contraseña = '" + contraseña + "'";
            MySqlCommand cmd = new MySqlCommand(cadenaValUsuario, conectar);

            MySqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                regresa = reader.GetString(7);
            }
            return regresa;
        }

    

        //Formulario Registro

        //5--Insertar registros

        public static void registroUsuario(MySqlConnection conectar, string Id, string Nombre, string Paterno, string Materno, string Cuenta, string Placas, string Contraseña, string Nivel)

        {

            string cadenaSql = "Insert into bdnube(Id,Nombre,Paterno,Materno,Cuenta,Placas,Contraseña,Nivel) values(@Id,@Nombre, @Paterno,@Materno,@Cuenta,@Placas,@Contraseña,@Nivel)";
            MySqlCommand cmd = new MySqlCommand(cadenaSql, conectar);

            cmd.Parameters.AddWithValue("@Id", Id);
            cmd.Parameters.AddWithValue("@Nombre", Nombre);
            cmd.Parameters.AddWithValue("@Paterno", Paterno);
            cmd.Parameters.AddWithValue("@Materno", Materno);
            cmd.Parameters.AddWithValue("@Cuenta", Cuenta);
            cmd.Parameters.AddWithValue("@Placas", Placas);
            cmd.Parameters.AddWithValue("@Contraseña", Contraseña);
            cmd.Parameters.AddWithValue("@Nivel", Nivel);

            try
            {
                cmd.ExecuteNonQuery();


                MessageBox.Show(Nombre + "Registrado");

            }
            catch
            {

                MessageBox.Show("Error no se guardo el registro");

            }

        }



        //Formulario Actualizar

       
        public static void Actualizar(MySqlConnection conectar, string Id, string Nombre, string Paterno, string Materno, string Cuenta, string Placas, string Contraseña, string Nivel)

        {

            string cadenaSql = "UPDATE bdnube SET Nombre = @Nombre,Paterno = @Paterno,Materno = @Materno,Cuenta = @Cuenta,Placas = @Placas,Contraseña = @Contraseña,Nivel = @Nivel WHERE Id=@Id ";
            MySqlCommand cmd = new MySqlCommand(cadenaSql, conectar);

            cmd.Parameters.AddWithValue("@Id", Id);
            cmd.Parameters.AddWithValue("@Nombre",Nombre);
            cmd.Parameters.AddWithValue("@Paterno", Paterno);
            cmd.Parameters.AddWithValue("@Materno", Materno);
            cmd.Parameters.AddWithValue("@Cuenta", Cuenta);
            cmd.Parameters.AddWithValue("@Placas", Placas);
            cmd.Parameters.AddWithValue("@Contraseña", Contraseña);
            cmd.Parameters.AddWithValue("@Nivel", Nivel);

            cmd.ExecuteNonQuery();
            conectar.Close();
            MessageBox.Show("Actualizado  " +Id);
        }


        //Formulario Eliminar

        public static void Eliminar(MySqlConnection conectar, string Id)

        {

            string cadenaSql = "DELETE FROM bdnube  Where Id = @Id";
            MySqlCommand cmd = new MySqlCommand(cadenaSql, conectar);

            cmd.Parameters.AddWithValue("@Id", Id);

            try
            {
                cmd.ExecuteNonQuery();

                MessageBox.Show("Usuario eliminado:   " + Id);

            }
            catch
            {
                MessageBox.Show("No se pudo eliminar:  " + Id);
            }
            conectar.Close();
        }


        //////////////////////////////////////////


        //Formularios DEL TARJETON 

       

        // 1- Metodo de Bienvenido (No.tarjeton)VALIDACION DEL TARJETON

        public static string ValTarjeton(MySqlConnection conectar, string Tarjeton)
        {

            string inicio = null; ;
            string cadenaValTarjeton = "select * from bdtarjeton where Tarjeton = @Tarjeton";
            MySqlCommand cmd = new MySqlCommand(cadenaValTarjeton, conectar);
          
            //cmd.Parameters.AddWithValue("@Tarjeton",Tarjeton);
            //cmd.ExecuteNonQuery();
            //conectar.Close();
            //MessageBox.Show("Bienvenido a Unitec:   " + Tarjeton);
            //if (cadenaValTarjeton == Tarjeton)
            //{

            //}
            return inicio;


        }


        //4--Metodo de acceso = si el ID no existe no entra 

        public static string ConsultaEntrada(MySqlConnection conectar, string Tarjeton)
        {
            string valida = null;
            string cadenaValTarjeton = "select * from bdtarjeton  where Tarjeton= '" + Tarjeton + "'";
            MySqlCommand cmd = new MySqlCommand(cadenaValTarjeton, conectar);

            MySqlDataReader reader = cmd.ExecuteReader();
           
            while (reader.Read())
            {
                valida = reader.GetString(0);
            }
            return valida;
        }






        // Metodos para el Registro y eliminar tarjeton 

        //2--Insertar registrosTarjeton

        public static void registroTarjeton(MySqlConnection conectar, string Tarjeton, string Nombre, string Paterno, string Materno, string Cuenta,  string Nivel, string Placas)

        {

            string cadenaSql = "Insert into bdtarjeton(Tarjeton,Nombre,Paterno,Materno,Cuenta,Nivel,Placas) values(@Tarjeton,@Nombre, @Paterno,@Materno,@Cuenta,@Nivel,@Placas)";
            MySqlCommand cmd = new MySqlCommand(cadenaSql, conectar);

            cmd.Parameters.AddWithValue("@Tarjeton", Tarjeton);
            cmd.Parameters.AddWithValue("@Nombre", Nombre);
            cmd.Parameters.AddWithValue("@Paterno", Paterno);
            cmd.Parameters.AddWithValue("@Materno", Materno);
            cmd.Parameters.AddWithValue("@Cuenta", Cuenta);
            cmd.Parameters.AddWithValue("@Nivel", Nivel);
            cmd.Parameters.AddWithValue("@Placas", Placas);
     

            try
            {
                cmd.ExecuteNonQuery();


                MessageBox.Show( "El Tarjeton:" + Tarjeton + "  a sido registrado ");

            }
            catch
            {

                MessageBox.Show("Error no se guardo el registro");

            }

        }

        //Formulario EliminarTarjeton

        public static void EliminarTar(MySqlConnection conectar, string Tarjeton)

        {

            string cadenaSql = "DELETE FROM bdtarjeton Where Tarjeton = @Tarjeton";
            MySqlCommand cmd = new MySqlCommand(cadenaSql, conectar);

            cmd.Parameters.AddWithValue("@Tarjeton", Tarjeton);

            try
            {
                cmd.ExecuteNonQuery();

                MessageBox.Show("Usuario eliminado:    " + Tarjeton);

            }
            catch
            {
                MessageBox.Show("No se pudo eliminar:   " + Tarjeton);
            }
            conectar.Close();
        }




        ///FORMULARIO PARA VISITANTE ENTRADA

        public static void VisiEntrada(MySqlConnection conectar, string Placas, string Motivo)

        {

            string cadenaSql = "Insert into bdvisitante(Placas,Motivo) values(@Placas,@Motivo)";
            MySqlCommand cmd = new MySqlCommand(cadenaSql, conectar);

          
            cmd.Parameters.AddWithValue("@Placas", Placas);
            cmd.Parameters.AddWithValue("@Motivo", Motivo);


          
                cmd.ExecuteNonQuery();


                MessageBox.Show("Bienvenido a Unitec");

        

        }

        //Formulario VisitanteSalida

        public static void EliminarVisita(MySqlConnection conectar, string Placas)

        {

            string cadenaSql = "DELETE FROM bdvisitante Where Placas = @Placas";
            MySqlCommand cmd = new MySqlCommand(cadenaSql, conectar);

            cmd.Parameters.AddWithValue("@Placas", Placas);

           
                cmd.ExecuteNonQuery();

                MessageBox.Show(" Buen viaje, regrese pronto");

       
       
        }


        //Llave de Class
    }


    //Llaves de cierre

}
