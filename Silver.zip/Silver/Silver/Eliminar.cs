﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using MySql.Data.MySqlClient;

namespace Silver
{
    public partial class Eliminar : Form
    {
        public Eliminar()
        {
            InitializeComponent();
        }

        //Para arrastrar la interfaz

        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lparam);


        private void registro_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
           
        }

        //Boton ELiminar
        private void button1_Click(object sender, EventArgs e)
        {

            BaseDatos.Eliminar(BaseDatos.ConectarBd(), textBox1.Text);
            
           
        }


    
        //Boton de Limpiar
        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
         
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void Nombre_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        //CRUD
        private void button3_Click(object sender, EventArgs e)
        {
            MySqlCommand cmd = new MySqlCommand("SELECT * FROM bdnube", BaseDatos.ConectarBd());
            MySqlDataAdapter ver = new MySqlDataAdapter();
            ver.SelectCommand = cmd;
            DataTable tabla = new DataTable();
            ver.Fill(tabla);
            dataGridView1.DataSource = tabla;

        }

        private void gunaAdvenceButton3_Click(object sender, EventArgs e)
        {
            Actualizar actual = new Actualizar();
            this.Hide();
            actual.Show();
        }

        private void gunaAdvenceButton1_Click(object sender, EventArgs e)
        {
            Buscar bus = new Buscar();
            this.Hide();
            bus.Show();
        }

        private void gunaAdvenceButton2_Click(object sender, EventArgs e)
        {
            registro regis = new registro();
            this.Hide();
            regis.Show();
        }

        private void bunifuSeparator3_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void label11_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void panel2_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void Eliminar_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            Form1 login = new Form1();
            this.Hide();
            login.Show();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
    }
}
