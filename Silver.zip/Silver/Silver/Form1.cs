﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using MySql.Data.MySqlClient;
using System.Diagnostics;

namespace Silver
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Para arrastrar la interfaz

        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lparam);

        private void button1_Click(object sender, EventArgs e)
        {

            if (BaseDatos.ConsultaAcceso(BaseDatos.ConectarBd(), textBox1.Text,textBox2.Text) == null)
            {

                MessageBox.Show("No existe el ID:   " +textBox1.Text);
                textBox1.Clear();
                textBox2.Clear();
            }
            else
                if (BaseDatos.ConsultaNivel(BaseDatos.ConectarBd(), textBox1.Text,textBox2.Text) == "Administrador")
            {
                
              
                registro regis = new registro();
                this.Hide();
                regis.Show();
            }
            else
            {
                if (BaseDatos.ConsultaNivel(BaseDatos.ConectarBd(), textBox1.Text, textBox2.Text) == "Usuario")
                {
                    Menu menu = new Menu();
                    this.Hide();
                    menu.Show();
                }
              
            }


            ////if (BaseDatos.ValUsuario(BaseDatos.ConectarBd(),textBox1.Text, textBox2.Text)!=null)
            ////{
            ////    registro regis = new registro();
            ////    regis.Show();
            ////}
            ////else
            ////{
            ////    MessageBox.Show("ERROR");
            ////}


            //MySqlConnection conectar = new MySqlConnection("server=bu2dhmwtysjpqzgxggtc-mysql.services.clever-cloud.com;port=3306;database=bu2dhmwtysjpqzgxggtc;user=uzqtm0ogszmhzb2m;password=AYZhDxXQgM2bzEWhb54F;");
            //conectar.Open();

            //MySqlCommand codigo = new MySqlCommand();
            //MySqlConnection conectarse = new MySqlConnection();
            //codigo.Connection = conectar;
            //codigo.CommandText = ("select * from admin where id = '" + textBox1.Text + "' and contraseña = '" + textBox2.Text + "' ");


            //MySqlDataReader leer = codigo.ExecuteReader();
            //if (leer.Read())
            //{
            //    if (textBox1.Text == "123456")
            //    {
            //        registro regis = new registro();
            //        regis.Show();
            //        MessageBox.Show("Bienvenido");
            //    }
            //    else
            //    {
            //        Menu regisMenu = new Menu();
            //        regisMenu.Show();


            //    }

            //}




        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        //Boton "x"

        private void label11_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

     

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            Process.Start(@"https://uniteconline.blackboard.com/");
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            Process.Start(@"https://outlook.live.com/owa/");
        }

        private void textBox1_Enter(object sender, EventArgs e)
        {
            //if (textBox1.Text == "Id Usuario")
            //{
            //    textBox1.Text = "";
            //}
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            //if (textBox1.Text == "")
            //{
            //    textBox1.Text = "Id Usuario";
            //}
        }
        private void textBox2_Enter(object sender, EventArgs e)
        {
            //if (textBox2.Text == "Contraseña")
            //{
            //    textBox2.Text = "";
              
            //    //textBox2.Text.UseSystemPasswordChar = true;
            //}
        }

        private void textBox2_Leave(object sender, EventArgs e)
        {
            //if (textBox2.Text == "")
            //{
            //    textBox2.Text = "Contraseña";
            //    //textBox2.Text.UseSystemPasswordChar = false;
            //}
        }

        private void bunifuSeparator2_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void bunifuTextbox1_OnTextChange(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        //Minimizar
        private void pictureBox4_Click_1(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
    }

    //llave de cierre
}
