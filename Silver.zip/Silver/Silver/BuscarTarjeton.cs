﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using MySql.Data.MySqlClient;

namespace Silver
{
    public partial class BuscarTarjeton : Form
    {
        public BuscarTarjeton()
        {
            InitializeComponent();
        }

        //Para arrastrar la interfaz

        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lparam);


        private void registro_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
           
        }

        //Boton BUSCAR
        private void button1_Click(object sender, EventArgs e)
        {
         
                         
            MySqlCommand cmd = new MySqlCommand("SELECT * FROM bdtarjeton WHERE Tarjeton = @Tarjeton", BaseDatos.ConectarBd());

            cmd.Parameters.AddWithValue("@Tarjeton", textBox1.Text);
            MySqlDataReader busca = cmd.ExecuteReader();
            if (busca.Read())
            {
                textBox2.Text = busca["Nombre"].ToString();
                textBox3.Text = busca["Materno"].ToString();
                textBox4.Text = busca["Paterno"].ToString();
                textBox5.Text = busca["Cuenta"].ToString();
                textBox6.Text = busca["Placas"].ToString();
                comboBox1.Text = busca["Nivel"].ToString();
            }

        }



        //Boton de Limpiar
        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            //textBox2.Clear();
            //textBox3.Clear();
            //textBox4.Clear();
            //textBox5.Clear();
            //textBox6.Clear();
            //textBox7.Clear();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void Nombre_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void panel2_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void Buscar_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void label11_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            Form1 login = new Form1();
            this.Hide();
            login.Show();
        }

        private void bunifuSeparator3_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

    

        //Boton de ir a Eliminar
        private void gunaAdvenceButton2_Click(object sender, EventArgs e)
        {
            EliminarTarjeton eliTar = new EliminarTarjeton();
            this.Hide();
            eliTar.Show();
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }


        //Ir al menu tarjeton
        private void gunaAdvenceButton4_Click(object sender, EventArgs e)
        {
            Menu men = new Menu();
            this.Hide();
            men.Show();
        }

        private void gunaAdvenceButton3_Click(object sender, EventArgs e)
        {
            RTarjeton tar = new RTarjeton();
            this.Hide();
            tar.Show();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
    }
}
